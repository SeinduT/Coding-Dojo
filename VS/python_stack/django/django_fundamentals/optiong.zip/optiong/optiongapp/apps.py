from django.apps import AppConfig


class OptiongappConfig(AppConfig):
    name = 'optiongapp'
