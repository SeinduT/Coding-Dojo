from django.apps import AppConfig


class OptionnappConfig(AppConfig):
    name = 'optionNapp'
