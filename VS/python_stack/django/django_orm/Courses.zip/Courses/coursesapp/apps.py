from django.apps import AppConfig


class CoursesappConfig(AppConfig):
    name = 'coursesapp'
