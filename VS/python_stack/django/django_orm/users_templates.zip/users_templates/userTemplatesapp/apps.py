from django.apps import AppConfig


class UsertemplatesappConfig(AppConfig):
    name = 'userTemplatesapp'
